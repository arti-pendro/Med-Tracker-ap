package com.hackumass.med.medapp.Weather;

/**
 * Created by Aryan Singh on 10/13/2018.
 */

public class Weather {
}
