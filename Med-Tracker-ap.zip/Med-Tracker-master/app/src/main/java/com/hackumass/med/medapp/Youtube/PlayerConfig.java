package com.hackumass.med.medapp.Youtube;

/**
 * Created by Aryan Singh on 10/14/2018.
 */

public class PlayerConfig {

    public static final String YOUTUBE_API = "AIzaSyAiliRaiWFMGBURP4LaQHPNWxLwyealow0";
    public PlayerConfig(){

    }


}
