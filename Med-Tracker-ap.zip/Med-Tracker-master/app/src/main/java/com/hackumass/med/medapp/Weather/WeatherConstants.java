package com.hackumass.med.medapp.Weather;

/**
 * Created by Aryan Singh on 10/13/2018.
 */

public class WeatherConstants {
    public final static String WEATHER_API = "9ad78b8a08f39899131b8d657929446e";

}